import "dotenv/config";

export const config = {
  port: Number(process.env.PORT || 3000),
  frontendOrigin: process.env.FRONTEND_ORIGIN || "http://localhost:5500",
  paypal: {
    clientId: process.env.PAYPAL_CLIENT_ID || "XXXXX",
    clientSecret: process.env.PAYPAL_CLIENT_SECRET || "XXXXX",
    environment: process.env.PAYPAL_ENVIRONMENT || "SANDBOX",
    webhookId: process.env.PAYPAL_WEBHOOK_ID || "XXXXX",
  },
  sessionSecret: process.env.SESSION_SECRET || "XXXXX",
  adminEmail: process.env.ADMIN_EMAIL || "XXXXX",
  adminPasswordHash: process.env.ADMIN_PASSWORD_HASH || "XXXXX",
  privateStoragePath: process.env.PRIVATE_STORAGE_PATH || "./storage/private",
  previewStoragePath: process.env.PREVIEW_STORAGE_PATH || "./storage/previews",
};
