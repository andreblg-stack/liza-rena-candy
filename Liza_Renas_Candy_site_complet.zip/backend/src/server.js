import "dotenv/config";
import path from "node:path";
import fs from "node:fs/promises";
import crypto from "node:crypto";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import multer from "multer";
import mime from "mime-types";
import {config} from "./config.js";
import {loadDb,saveDb,id,token} from "./db.js";
import {createPayPalOrder,capturePayPalOrder,paypalClientToken,verifyWebhook} from "./paypal.js";

const app=express();
app.set("trust proxy",1);
app.use(helmet({crossOriginResourcePolicy:{policy:"cross-origin"}}));
app.use(cors({origin:config.frontendOrigin}));
app.use(rateLimit({windowMs:60_000,max:120}));
app.use("/api/paypal/webhook", express.raw({type:"application/json"}));
app.use(express.json({limit:"200kb"}));

await fs.mkdir(path.resolve(config.privateStoragePath),{recursive:true});
await fs.mkdir(path.resolve(config.previewStoragePath),{recursive:true});

function publicProduct(p){
  return {...p, originalFile:undefined};
}

app.get("/api/products",async(req,res)=>{
  const db=await loadDb();
  let products=db.products.filter(p=>p.published);
  if(req.query.featured==="true") products=products.filter(p=>p.featured);
  res.json({products:products.map(publicProduct)});
});

app.get("/api/products/:id",async(req,res)=>{
  const db=await loadDb();
  const p=db.products.find(x=>x.id===req.params.id && x.published);
  if(!p)return res.status(404).json({error:"Produit introuvable"});
  res.json({product:publicProduct(p)});
});

app.get("/api/paypal/client-token",async(req,res)=>{
  try{
    const clientToken=await paypalClientToken();
    res.json({clientToken,environment:config.paypal.environment});
  }catch(e){res.status(503).json({error:"PayPal n'est pas configuré."});}
});

app.post("/api/orders",async(req,res)=>{
  try{
    const ids=Array.isArray(req.body.productIds)?req.body.productIds:[];
    if(!ids.length || ids.length>50)return res.status(400).json({error:"Panier invalide"});
    const db=await loadDb();
    const products=ids.map(i=>db.products.find(p=>p.id===i && p.published)).filter(Boolean);
    if(products.length!==ids.length)return res.status(400).json({error:"Produit indisponible"});
    const currencies=new Set(products.map(p=>p.currency));
    if(currencies.size!==1)return res.status(400).json({error:"Devises incompatibles"});
    const currency=products[0].currency;
    const total=products.reduce((s,p)=>s+Number(p.price),0);
    const pp=await createPayPalOrder(total,currency,products);
    const internal=id("ord");
    db.orders.push({id:internal,paypalOrderId:pp.id,productIds:products.map(p=>p.id),currency,total,status:"PENDING",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()});
    await saveDb(db);
    res.json({orderId:internal,paypalOrderId:pp.id});
  }catch(e){console.error(e);res.status(500).json({error:"Impossible de créer la commande"});}
});

app.post("/api/orders/:paypalOrderId/capture",async(req,res)=>{
  try{
    const db=await loadDb();
    const order=db.orders.find(o=>o.paypalOrderId===req.params.paypalOrderId);
    if(!order)return res.status(404).json({error:"Commande introuvable"});
    if(order.status==="PAID")return res.json({status:"PAID",orderId:order.id});
    const data=await capturePayPalOrder(order.paypalOrderId);
    const captureStatus=data.status==="COMPLETED" ? "PAID" : "FAILED";
    order.status=captureStatus; order.updatedAt=new Date().toISOString();
    if(captureStatus==="PAID"){
      order.captureId=data.purchase_units?.[0]?.payments?.captures?.[0]?.id || null;
      order.email=data.payer?.email_address || null;
    }
    await saveDb(db);
    res.json({status:order.status,orderId:order.id});
  }catch(e){console.error(e);res.status(500).json({error:"Impossible de confirmer le paiement"});}
});

app.get("/api/orders/:id",async(req,res)=>{
  const db=await loadDb();
  const order=db.orders.find(o=>o.id===req.params.id);
  if(!order)return res.status(404).json({error:"Commande introuvable"});
  if(order.status!=="PAID")return res.json({ok:true,status:order.status,downloads:[]});
  const downloads=[];
  for(const productId of order.productIds){
    const p=db.products.find(x=>x.id===productId);
    if(!p || !p.originalFile)continue;
    const raw=token();
    const hash=crypto.createHash("sha256").update(raw).digest("hex");
    db.downloadTokens.push({id:id("dl"),hash,orderId:order.id,productId,expiresAt:new Date(Date.now()+24*3600*1000).toISOString(),downloadCount:0,maxDownloads:3,revoked:false});
    downloads.push({title:p.title,url:`${config.frontendOrigin.replace(/\/$/,"")}/api/download/${raw}`});
  }
  await saveDb(db);
  res.json({ok:true,status:order.status,downloads});
});

app.get("/api/download/:rawToken",async(req,res)=>{
  const db=await loadDb();
  const hash=crypto.createHash("sha256").update(req.params.rawToken).digest("hex");
  const entry=db.downloadTokens.find(t=>t.hash===hash);
  if(!entry || entry.revoked || entry.downloadCount>=entry.maxDownloads || new Date(entry.expiresAt)<new Date())return res.status(404).send("Lien de téléchargement invalide ou expiré.");
  const order=db.orders.find(o=>o.id===entry.orderId);
  if(!order || order.status!=="PAID")return res.status(403).send("Paiement non confirmé.");
  const p=db.products.find(x=>x.id===entry.productId);
  if(!p || !p.originalFile)return res.status(404).send("Fichier introuvable.");
  const file=path.resolve(config.privateStoragePath,p.originalFile);
  try{await fs.access(file);}catch{return res.status(404).send("Fichier introuvable.");}
  entry.downloadCount++;
  await saveDb(db);
  res.download(file,path.basename(file));
});

app.post("/api/paypal/webhook",async(req,res)=>{
  try{
    const raw=req.body;
    const event=JSON.parse(raw.toString("utf8"));
    const headers=Object.fromEntries(Object.entries(req.headers).map(([k,v])=>[k.toLowerCase(),v]));
    const valid=await verifyWebhook({headers,event});
    if(!valid)return res.status(400).send("Invalid signature");
    const db=await loadDb();
  }catch(e){
    console.error(e);return res.status(400).send("Webhook error");
  }
});

const upload=multer({dest:path.resolve("storage/tmp"),limits:{fileSize:25*1024*1024}});
app.post("/api/admin/products",upload.fields([{name:"preview",maxCount:1},{name:"original",maxCount:1}]),async(req,res)=>{
  // Placeholder admin protection: production MUST use real authenticated sessions.
  if(req.headers["x-admin-placeholder"]!=="XXXXX")return res.status(401).json({error:"Authentification administrateur requise"});
  const db=await loadDb();
  const p={id:id("prod"),title:String(req.body.title||"XXXXX"),slug:String(req.body.slug||crypto.randomUUID()),description:String(req.body.description||""),price:Number(req.body.price||0),currency:String(req.body.currency||"EUR"),category:String(req.body.category||"XXXXX"),previewUrl:"/previews/placeholder.svg",originalFile:null,type:String(req.body.type||"photo"),license:String(req.body.license||"XXXXX"),published:req.body.published==="true",featured:req.body.featured==="true",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
  db.products.push(p); await saveDb(db); res.json({product:publicProduct(p)});
});

app.use("/previews",express.static(path.resolve(config.previewStoragePath),{index:false,maxAge:"7d"}));
app.get("/health",(req,res)=>res.json({ok:true}));

app.listen(config.port,()=>console.log(`Liza Rena’s Candy backend listening on :${config.port}`));
