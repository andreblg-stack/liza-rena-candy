import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";

const dataDir = path.resolve("data");
const dbFile = path.join(dataDir, "store.json");

const initial = {
  products: [
    {id:"photo-001", title:"XXXXX", slug:"xxxxx", description:"XXXXX", price:5, currency:"EUR", category:"XXXXX", previewUrl:"/previews/example-1.svg", originalFile:"XXXXX", type:"photo", license:"XXXXX", published:true, featured:true, createdAt:new Date().toISOString(), updatedAt:new Date().toISOString()},
    {id:"photo-002", title:"XXXXX", slug:"xxxxx-2", description:"XXXXX", price:7, currency:"EUR", category:"XXXXX", previewUrl:"/previews/example-2.svg", originalFile:"XXXXX", type:"photo", license:"XXXXX", published:true, featured:true, createdAt:new Date().toISOString(), updatedAt:new Date().toISOString()}
  ],
  categories:["Portraits","Nature","Lifestyle","Artistique","Noir & blanc","Collections","Vidéos"],
  orders: [],
  downloadTokens: [],
  webhookEvents: []
};

export async function loadDb(){
  await fs.mkdir(dataDir,{recursive:true});
  try{return JSON.parse(await fs.readFile(dbFile,"utf8"));}catch{await saveDb(initial);return structuredClone(initial);}
}
export async function saveDb(db){await fs.writeFile(dbFile,JSON.stringify(db,null,2));}
export function id(prefix){return `${prefix}_${crypto.randomUUID()}`;}
export function token(){return crypto.randomBytes(32).toString("hex");}
