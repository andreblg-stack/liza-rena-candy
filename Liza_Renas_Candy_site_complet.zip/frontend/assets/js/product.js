(async () => {
  const root = document.getElementById("product-page");
  const id = new URLSearchParams(location.search).get("id");
  if(!id){root.innerHTML='<div class="notice">Œuvre introuvable.</div>';return;}
  try{
    const data = await LRCStore.api(`/api/products/${encodeURIComponent(id)}`);
    const p = data.product;
    root.innerHTML = `<div>
      <img class="product-hero-image" src="${esc(p.previewUrl)}" alt="${esc(p.title)}">
    </div>
    <div class="product-meta">
      <p class="eyebrow">${esc(p.category||"ŒUVRE")}</p>
      <h1>${esc(p.title)}</h1>
      <p class="muted">${esc(p.description||"")}</p>
      <div class="price">${LRCStore.money(p.price,p.currency)}</div>
      <div class="notice">Aperçu protégé. Le fichier original HD est délivré uniquement après confirmation du paiement.</div>
      <div style="margin-top:22px"><button id="add" class="button button-pink">Ajouter au panier</button></div>
    </div>`;
    document.getElementById("add").onclick=()=>{LRCStore.add(p);location.href="./cart.html";};
  }catch(e){root.innerHTML=`<div class="notice">${esc(e.message)}</div>`}
  function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
})();
