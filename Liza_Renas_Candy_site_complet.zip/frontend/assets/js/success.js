(async () => {
  const area=document.getElementById("download-area");
  const order=new URLSearchParams(location.search).get("order") || localStorage.getItem("lrc_last_order");
  if(!order){area.innerHTML='<p class="muted">Numéro de commande manquant.</p>';return;}
  try{
    const data=await fetch(`${window.LRC_CONFIG.API_BASE_URL}/api/orders/${encodeURIComponent(order)}`).then(r=>r.json());
    if(!data.ok || data.status!=="PAID"){area.innerHTML='<p class="muted">Le paiement est en cours de confirmation. Rechargez cette page dans quelques instants.</p>';return;}
    area.innerHTML=data.downloads.map(d=>`<a class="button" href="${d.url}">Télécharger — ${escape(d.title)}</a>`).join("");
  }catch(e){area.innerHTML='<p class="muted">Téléchargement indisponible pour le moment.</p>';}
  function escape(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
})();
