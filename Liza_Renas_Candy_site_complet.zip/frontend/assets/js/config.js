window.LRC_CONFIG = {
  API_BASE_URL: "http://localhost:3000",
  PAYPAL_CLIENT_TOKEN_ENDPOINT: "/api/paypal/client-token"
};
