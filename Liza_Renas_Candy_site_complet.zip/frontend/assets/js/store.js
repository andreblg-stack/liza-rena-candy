window.LRCStore = (() => {
  const CART_KEY = "lrc_cart_v1";
  const getCart = () => JSON.parse(localStorage.getItem(CART_KEY) || "[]");
  const setCart = (cart) => { localStorage.setItem(CART_KEY, JSON.stringify(cart)); updateCartCount(); };
  const updateCartCount = () => {
    const el = document.getElementById("cart-count");
    if (el) el.textContent = getCart().length;
  };
  const add = (product) => {
    const cart = getCart().filter(p => p.id !== product.id);
    cart.push({id: product.id, title: product.title, price: product.price, currency: product.currency, previewUrl: product.previewUrl});
    setCart(cart);
  };
  const remove = (id) => setCart(getCart().filter(p => p.id !== id));
  const clear = () => setCart([]);
  const money = (value, currency="EUR") => new Intl.NumberFormat("fr-FR", {style:"currency", currency}).format(value);
  const api = async (path, options={}) => {
    const res = await fetch(`${window.LRC_CONFIG.API_BASE_URL}${path}`, {headers: {"Content-Type":"application/json", ...(options.headers||{})}, ...options});
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Erreur serveur");
    return data;
  };
  updateCartCount();
  return {getCart,setCart,add,remove,clear,money,api,updateCartCount};
})();
