(() => {
  const root = document.getElementById("cart");
  function render(){
    const cart = LRCStore.getCart();
    if(!cart.length){root.innerHTML='<div class="notice">Votre panier est vide.<br><br><a class="button" href="./gallery.html">Découvrir les œuvres</a></div>';return;}
    const total=cart.reduce((s,p)=>s+Number(p.price),0);
    root.innerHTML = cart.map(p=>`<div class="cart-row"><img class="cart-thumb" src="${esc(p.previewUrl)}" alt="${esc(p.title)}"><div><h3>${esc(p.title)}</h3><span class="muted">${esc(p.currency)}</span></div><div><strong>${LRCStore.money(p.price,p.currency)}</strong><br><button class="small-btn" data-remove="${esc(p.id)}">Retirer</button></div></div>`).join("")+
      `<div class="cart-total"><span>Total</span><span>${LRCStore.money(total,cart[0].currency||"EUR")}</span></div><div style="display:flex;justify-content:flex-end"><a class="button button-pink" href="./checkout.html">Payer avec PayPal</a></div>`;
    root.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{LRCStore.remove(b.dataset.remove);render();});
  }
  render();
  function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
})();
