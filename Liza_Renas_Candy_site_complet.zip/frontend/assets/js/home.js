(async () => {
  const grid = document.getElementById("featured-grid");
  try {
    const data = await LRCStore.api("/api/products?featured=true");
    grid.innerHTML = data.products.map(productCard).join("");
  } catch (e) {
    grid.innerHTML = `<div class="notice">Le catalogue sera disponible après configuration du backend.</div>`;
  }

  function productCard(p){
    return `<article class="product-card">
      <img class="product-image" src="${escapeAttr(p.previewUrl)}" alt="${escapeAttr(p.title)}" loading="lazy">
      <div class="product-body">
        <p class="eyebrow">${escapeHtml(p.category || "ŒUVRE")}</p>
        <h3 class="product-title">${escapeHtml(p.title)}</h3>
        <div class="card-actions">
          <span class="price">${LRCStore.money(p.price,p.currency)}</span>
          <a class="small-btn" href="./product.html?id=${encodeURIComponent(p.id)}">Découvrir</a>
        </div>
      </div>
    </article>`;
  }
  function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
  function escapeAttr(s){return escapeHtml(s)}
})();
