(async () => {
  const grid = document.getElementById("gallery-grid");
  const search = document.getElementById("search");
  const category = document.getElementById("category");
  const sort = document.getElementById("sort");
  let products = [];

  try {
    const data = await LRCStore.api("/api/products");
    products = data.products;
    [...new Set(products.map(p => p.category).filter(Boolean))].sort().forEach(c => {
      category.insertAdjacentHTML("beforeend", `<option value="${escape(c)}">${escape(c)}</option>`);
    });
    render();
  } catch(e) {
    grid.innerHTML = `<div class="notice">Impossible de charger les œuvres. Vérifie que le backend est en ligne.</div>`;
  }

  [search,category,sort].forEach(el => el.addEventListener("input", render));

  function render(){
    let list = products.filter(p => {
      const q = search.value.trim().toLowerCase();
      return (!q || `${p.title} ${p.description||""}`.toLowerCase().includes(q))
        && (!category.value || p.category === category.value);
    });
    if(sort.value==="price-asc") list.sort((a,b)=>a.price-b.price);
    if(sort.value==="price-desc") list.sort((a,b)=>b.price-a.price);
    if(sort.value==="newest") list.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
    grid.innerHTML = list.length ? list.map(card).join("") : `<div class="notice">Aucune œuvre ne correspond à votre recherche.</div>`;
  }
  function card(p){
    return `<article class="product-card"><img class="product-image" src="${escape(p.previewUrl)}" alt="${escape(p.title)}" loading="lazy"><div class="product-body"><p class="eyebrow">${escape(p.category||"ŒUVRE")}</p><h3 class="product-title">${escape(p.title)}</h3><div class="card-actions"><span class="price">${LRCStore.money(p.price,p.currency)}</span><a class="small-btn" href="./product.html?id=${encodeURIComponent(p.id)}">Voir</a></div></div></article>`;
  }
  function escape(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
})();
