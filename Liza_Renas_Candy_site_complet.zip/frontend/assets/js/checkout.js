(async () => {
  const cart = LRCStore.getCart();
  const summary = document.getElementById("checkout-summary");
  const msg = document.getElementById("payment-message");
  if(!cart.length){location.href="./cart.html";return;}
  const total=cart.reduce((s,p)=>s+Number(p.price),0);
  summary.innerHTML = `<div class="notice">1 commande · ${cart.length} œuvre(s) · Total : <strong>${LRCStore.money(total,cart[0].currency||"EUR")}</strong></div>`;
  msg.textContent = "Préparation de PayPal…";

  try{
    const tokenData = await LRCStore.api("/api/paypal/client-token");
    const sandbox = window.LRC_CONFIG.API_BASE_URL.includes("localhost") ? true : tokenData.environment === "SANDBOX";
    const sdkScript = sandbox ? "https://www.sandbox.paypal.com/web-sdk/v6/core" : "https://www.paypal.com/web-sdk/v6/core";
    await loadScript(sdkScript);
    const sdk = await window.paypal.createInstance({
      clientToken: tokenData.clientToken,
      components: ["paypal-payments"],
      pageType: "checkout",
      locale: "fr-FR",
      clientMetadataId: crypto.randomUUID()
    });
    const methods = await sdk.findEligibleMethods({currencyCode: cart[0].currency || "EUR"});
    if(!methods.isEligible("paypal")) throw new Error("PayPal n'est pas disponible pour cette configuration.");
    const session = sdk.createPayPalOneTimePaymentSession({
      onApprove: async ({orderId}) => {
        msg.textContent = "Vérification du paiement…";
        const result = await LRCStore.api(`/api/orders/${encodeURIComponent(orderId)}/capture`, {method:"POST"});
        if(result.status !== "PAID") throw new Error("Le paiement n'a pas pu être confirmé.");
        localStorage.setItem("lrc_last_order", result.orderId);
        LRCStore.clear();
        location.href = `./success.html?order=${encodeURIComponent(result.orderId)}`;
      },
      onCancel: () => { msg.textContent = "Paiement annulé."; },
      onError: (error) => { console.error(error); msg.textContent = "Une erreur PayPal est survenue."; }
    });
    const button = document.createElement("button");
    button.className="button button-pink";
    button.textContent="Payer avec PayPal";
    button.style.width="100%";
    button.onclick=async()=>{
      msg.textContent="Ouverture de PayPal…";
      const order = await LRCStore.api("/api/orders",{
        method:"POST",
        body:JSON.stringify({productIds:cart.map(p=>p.id)})
      });
      await session.start({presentationMode:"auto"}, Promise.resolve({orderId:order.paypalOrderId}));
    };
    document.getElementById("paypal-button-container").appendChild(button);
    msg.textContent="";
  }catch(e){
    console.error(e); msg.textContent=e.message||"PayPal n'est pas encore configuré.";
  }

  function loadScript(src){return new Promise((resolve,reject)=>{const s=document.createElement("script");s.src=src;s.onload=resolve;s.onerror=reject;document.head.appendChild(s);});}
})();
